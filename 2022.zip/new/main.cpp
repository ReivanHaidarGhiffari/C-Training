#include<stdio.h>
main()
{
    char n[30];
    int u,t;
    printf("masukan data diri anda\n nama:");
    scanf("%s",%n);
    printf("Umur:");
    scanf("%d",%u);
    printf("No.Telepon:");
    scanf("%d",%t);
    printf("hello %s, umur %d, no.telepon %d\n",n,u,t);
    printf("Bagaimana kabar anda hari ini?");
}
