#include <stdio.h>
#include <string.h>

main()
{
    char kar[256];
    char kar1[256];
    int a;
    int i;

    printf("Kalimat : ");
    gets(kar);



    for(i=0;i<a;i++)
    {
        if(kar[i]=='a')
            kar[i]='i';

    }
    printf("Jadi Kalimatnya sekarang adalah %s",kar);

}
