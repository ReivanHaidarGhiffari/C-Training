#include <stdio.h>
main()
{
    printf("*********\t*\t*\n");
    printf("*\t*\n");
    printf("*********\t*\t*");
}
