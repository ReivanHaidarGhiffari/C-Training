#include <stdio.h>
#include <string.h>

main()
{
    char kar[256];
    char kar1[256];
    int c;
    int i;
    char balik[36];
    int a,panjang, b=0;
    panjang = strlen(kar);

    printf("Kalimat : ");
    gets(kar);

    for(i=0;i<panjang;i++)
    {
        if(kar[i]=='i')
            kar[i]='a';

    }
    printf("Jadi Kalimatnya sekarang adalah : %s",kar);



/*for(a=strlen(kar); a>=0;a--)
{
balik[b]=kar[a];
b++;
}
printf("\nNama dibalik adalah:");
for(a=0; a<=panjang+36; a++)
printf("%c", balik[a]);
printf("\n");*/

}
