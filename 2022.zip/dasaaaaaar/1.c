#include <stdio.h>

main()
{
    float u,l;
    printf("Masukan nilai : ");
    scanf("%f",&u);
    l=1.0/2.0*3.14*u;
    printf("Jadi luas adalah: %f",l);
}
