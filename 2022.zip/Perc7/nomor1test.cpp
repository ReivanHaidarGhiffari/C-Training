#include <stdio.h>
main()
{
    int n,total;
    printf("Masukan jumlah data\n");
    scanf("%d",&n);

    total=jumlah();
    printf("jadi totalnya adalah %d",total);

}
int jumlah(int n)
{
    int i,total=0,bil;
    for(i=1;i<=n;i++)
    {
        printf("masukan bilangan ke %d",i);
        scanf("%d",&bil);
        if(bil%2==0)
            total=total+bil;

    }
    return total;
}
