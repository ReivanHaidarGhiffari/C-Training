#include <stdio.h>

main()
{
    char huruf;
    printf("masukkan nilai huruf : ");
    scanf("\n%c",&huruf);
if (huruf=='A')
    printf("nilai Angka 4\n");

    else if (huruf=='B')
        printf("nilai Angka 5\n");
    else if (huruf=='C')
        printf("nilai Angka 2\n");
    else if (huruf=='D')
        printf("nilai Angka 1\n");
    else if (huruf=='E')
        printf("nilai Angka 0\n");

    }
