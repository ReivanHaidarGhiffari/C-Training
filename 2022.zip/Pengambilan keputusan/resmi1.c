#include <stdio.h>

main()
{
    int pil,luas,panjang,lebar,tinggi,alas;
    printf("Masukkan pilihan anda: ");
    scanf("%d", &pil);

    switch(pil)
    {
    case 1:
        printf("Masukkan alas dan tinggi: ");
        scanf("%d %d",&tinggi,&alas);
        luas=0.5*alas*tinggi;
        printf("Jadi luasnya adalah %d ",luas);
        break;

    case 2:
        printf("Masukkan panjang dan lebar: ");
        scanf("%d %d",&panjang,&lebar);
        luas=panjang*lebar;
        printf("Jadi luasnya adalah %d ",luas);
        break;

    case 3:
        printf("Pilihan anda tidak tersedia\n ");
        break;

    }

}
