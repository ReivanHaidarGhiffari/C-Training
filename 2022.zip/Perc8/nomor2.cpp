#include <stdio.h>

float f_to_i(int kaki);
float i_to_cm(float inchi);
float c_to_m(float sentimeter);

main()
{
    int kaki;
    float sentimeter,meter,inchi;

    printf("masukan jumlah kaki\n");
    scanf("%d",&kaki);

    inchi=f_to_i(kaki);
    sentimeter=i_to_cm(inchi);
    meter=c_to_m(sentimeter);

    printf("jadi %d kaki adalah %f inchi %f cm dan %f m", kaki,inchi,sentimeter,meter);

}

float f_to_i(int kaki)
{
    return 12*kaki;
}

float i_to_cm(float inchi)
{
    return 2.54*inchi;
}

float c_to_m(float sentimeter)
{
    return sentimeter/100;

}
