#include <stdio.h>

main()

{
    float p,l,t,v;
    printf("Masukan Panjang, Lebar, Tinggi\n");
    printf("Panjang : ");
    scanf("%f",&p);
    printf("Lebar : ");
    scanf("%f",&l);
    printf("Tinggi : ");
    scanf("%f",&t);
    v= p*l*t;
    printf("Jadi Volumenya adalah %.0f cm kubik",v);


}
