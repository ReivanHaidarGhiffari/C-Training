#include <stdio.h>

main()
{
    int hari;
    printf("Hari ke..: ");
    scanf("%d",&hari);
    if(hari==1)
        printf("Minggu");
    else if(hari==2)
        printf("Senin");
    else if(hari==3)
        printf("selasa");
    else if(hari==4)
        printf("Rabu");
    else if(hari==5)
        printf("Kamis");
    else if(hari==6)
        printf("Jum'at");
    else if(hari==7)
        printf("Sabtu");





}
