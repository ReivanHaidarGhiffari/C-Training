#include <stdio.h>
main()
{
    printf("�Dalam membuat \�Program Komputer\� \n");
    printf("�Terdapat \\aturan \\aturan yang harus dipenuhi\n");
    printf("Dalam menuliskan perintah-perintah dasar\n");
    printf("�Untuk itu \�progammer\� harus menghafal aturan-aturan\n");
    printf("Yang berlaku.\n");

}
