#include <stdio.h>

main()
{
    int nilai;
    printf("Masukan nilai ujian : ");
    scanf("%d", &nilai);
    if(nilai>=70)
        printf("Anda Lulus");
    else
        printf("Anda Tidak Lulus");
}
