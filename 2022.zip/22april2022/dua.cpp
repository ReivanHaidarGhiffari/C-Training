#include <stdio.h>
main()
{
    int baris,kolom;
    for(baris=1;baris<=3;baris++)
    {
        for(kolom=1;kolom<=5;kolom++)
            printf("%5d",baris*kolom);
            printf("\n");

    }
}
