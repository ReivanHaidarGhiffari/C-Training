#include <stdio.h>

main()
{
    int x;
    x=23;
    printf("x = %d",x);
}
