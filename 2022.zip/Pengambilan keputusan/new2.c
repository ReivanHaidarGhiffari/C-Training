#include <stdio.h>>

main()
{
    char huruf;
    printf("masukkan nilai huruf \n");
    scanf("%c",&huruf);

    switch(huruf)
    {
       case 'A':
        printf("nilai Angka 4\n");
        break;
       case 'B':
        printf("nilai Angka 5\n");
        break;
       case 'C':
        printf("nilai Angka 2\n");
        break;
       case 'D':
        printf("nilai Angka 1\n");
        break;
       case 'E':
        printf("nilai Angka 0\n");
           break;
    }


}
