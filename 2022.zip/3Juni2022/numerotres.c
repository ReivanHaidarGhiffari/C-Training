#include <stdio.h>

main()
{
    char kar[256];
    char kar1[256];

    printf("Masukan kalimat pertama \n");
    gets(kar);

    printf("Masukan kalimat Kedua \n");
    gets(kar1);

    if(strcmp(kar,kar1)==0)
        printf("Kedua String sama");
    else
        printf("Kedua String tidak sama");
}
