#include <stdio.h>
main()
{
int i;
float total=0, rata_rata, nilai[3];
for (i=0; i<3; i++)
{
printf("masukkan nilai ");
if (i==0)
{
printf(" Matematika : \n");
}
else if (i==1)
{
printf(" Fisika : \n");
}
else
{
printf(" Kimia : \n");
}
scanf("%g", &nilai[i]);
fflush(stdin);
total+=nilai[i];
}
rata_rata=total/3;
printf("Nilai rata-ratanya adalah %g", rata_rata);
}
