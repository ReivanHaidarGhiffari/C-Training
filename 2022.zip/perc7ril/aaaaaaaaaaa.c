#include <stdio.h>
#include <string.h>
main()
{
 char nama1[255], nama2[255];
 int hitung;

 printf("Masukkan nama orang pertama: ");
 gets(nama1);
 printf("Masukkan nama orang kedua: ");
 gets(nama2);

 printf("Jika dibandingkan nama orang pertama dan kedua maka nilainya menjadi %d\n",strcmp(nama1,nama2));

 printf("Panjang karakter dari orang pertama adalah %d , sedangkan panjang karakter dari orang kedua adalah %d\n", strlen(nama1), strlen(nama2));

 hitung=strlen(nama1);
 printf("kata setelah dibalik : ");
 for(hitung-1;hitung>0;hitung--)
    {
        printf("%c", nama1[hitung-1]);
    }
 printf("\n");
}
