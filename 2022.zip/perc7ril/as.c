#include <stdio.h>
#include <string.h>
main()
{
    char nama{50};

    printf("Masukan String : ");
    gets(nama);
    printf("Jadi Panjang Stringnya Adalah : ",strlen(nama));
}
