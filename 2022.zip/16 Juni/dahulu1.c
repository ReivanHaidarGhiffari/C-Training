#include <stdio.h>
#include <string.h>
char a ="Halo Apa Kabar";
main()
{
    char *pB;
    pB = a;
    puts(pB);
}
