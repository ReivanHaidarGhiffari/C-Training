#include <stdio.h>
main()
{
    int total,i;
    for(i=0;i<5;i++)
        total=total+i;
    printf("Jadi nilanya adalah %d",total);
}
