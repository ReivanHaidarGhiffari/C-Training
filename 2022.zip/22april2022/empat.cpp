#include <stdio.h>
main()
{
    float a,b,c;

    printf("masukan nilai a dan b :");
    scanf("%d %d",&a,&b);

    if(b==0)
        goto tak_hingga;
    else
    {
        c=a/b;
        printf("hasilnya %.1f",c);
        goto selesai;
    }

    tak_hingga:
        printf("hasilnya tak hingga");
        selesai:
            ;
}
