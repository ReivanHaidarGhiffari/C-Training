#include <stdio.h>

main()
{
    char kar='a';
        kar=kar-32;
        printf("jadi hurufnya sekarang menjadi %c\n",kar);
}
