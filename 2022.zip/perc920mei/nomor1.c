#include <stdio.h>
main()
{
    char kar[256];
    int a=0,b=0,c=0;
    int n,i;
    printf("Masukan jumlah karakter yang akan dihitung:\n");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("Masukan karakter ke %d = ",i+1);
        scanf(" %c",&kar[i]);
        if(kar[i]=='a')
            a=a+1;

        else if(kar[i]=='b')
            b=b+1;
        else
            c=c+1;
        fflush(stdin);

    }
    printf("Frekuensi a=%d ",a);
    printf("Frekuensi b=%d ",b);
    printf("Frekuensi c=%d ",c);

}
