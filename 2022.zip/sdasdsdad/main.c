#include <stdio.h>
void tukar(int*a,int*b);
main()
{
    int a,b;
    printf("sdsad");
    scanf("%d %d", &a,&b);
    tukar(&a,&b);
    printf("a belum %d b belum %d",a,b);
}
void tukar(int*a,int*b);
{
 int c;
    c=*a;
    *a=*b;
    *b=c;
    printf("a belum %d b belum %d",a,b);
    tukar(&a,&b);
    printf("a belum %d b belum %d",a,b);
}


