#include <stdio.h>
#include <string.h>

main()
{
    char kar[256];
    char kar1[256];

    printf("Kalimat: ");
    gets(kar);

    strcpy(kar1,kar);
    strrev(kar1);

    if((strcmp(kar,kar1))==0)
        printf("Termasuk Palindrom\n");
    else
        printf("Bukan Palindrom\n");
}
