#include <stdio.h>

main()
{
    char nama[4][256];
    int baris;
    int i,j;
    char smtr[40];

    for(baris=0;baris<4;baris++)
    {
        printf("nama ke -%d : ",baris+1);
        gets(nama[baris]);
    }



    for(i=0;i<4;i++)
    {
        for(j=i+1;j<5;j++)
        {
            if(strcmp(nama[i],nama[j])==1)
            {
                strcpy(smtr,nama[i]);
                strcpy(nama[i],nama[j]);
                strcpy(nama[j],smtr);
            }
        }
    }

    printf("Setelah diurutkan\n");
    for(baris=0;baris<4;baris++)
    {
        printf("nama ke -%d : %s\n",baris+1,nama[baris]);
    }
}
