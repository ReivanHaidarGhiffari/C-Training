#include <stdio.h>

main()
{
    float u,l;
    printf("Masukan nilai : ");
    scanf("%f",&u);
    l=1/2*pi*u;
    printf("Jadi luas adalah: %f",l);
}
