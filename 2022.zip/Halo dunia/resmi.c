#include <stdio.h>
main()
{
    printf("%d MAWAR %d DURI\n",1,3);
    printf("ADA %s ADA %s\n","GULA","SEMUT");
}
