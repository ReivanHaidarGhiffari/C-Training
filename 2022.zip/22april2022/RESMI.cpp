#include <stdio.h>
#include <stdlib.h>
main()
{
    int m,i,j, jum=0;
    printf("Program untuk mentotal bilangan prima\n");
    printf("Masukan nilai m : \n");
    scanf("%d",&m);
    for (i=1; i<m+1; i++)
    {
        printf("Bilangan prima yang ke%d=",i);
        scanf("%d",&j);
        jum+= j;
    }
    printf("\n");
    printf("Total %d bil prima pertama = %d\n",m,jum);
}
