#include <stdio.h>

main()
{
    int pil,luas,panjang,lebar,tinggi,alas;
    printf("Masukkan pilihan anda: ");
    scanf("%d", &pil);

    if(pil==1)
    {
        printf("Masukkan alas dan tinggi: ");
        scanf("%d %d",&tinggi,&alas);
        luas=0.5*alas*tinggi;
    }
    else if (pil==2)
    {
        printf("Masukkan panjang dan lebar: ");
        scanf("%d %d",&panjang,&lebar);
        luas=panjang*lebar;
    }
    else

        printf("Pilihan anda tidak tersedia\n ");


        printf("Jadi luasnya adalah %d ",luas);


}
