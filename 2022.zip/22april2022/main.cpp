#include <stdio.h>
main()
{
    int n,baris,kolom,i;
    printf("masukan nilai:");
    scanf("%d",&n);

    for(baris=1;baris<=n;baris++)
    {
        for(kolom=1;kolom<=n-baris;kolom++)
            printf("");
        for(kolom=1;kolom<=baris;kolom++)
            printf("%c",'*');
        printf("\n");
    }

    for(baris=1;baris<=n-1;baris++)
    {
        for(kolom=1;kolom<=baris;kolom++)
            printf("");
        for(kolom=1;kolom<=4-baris;kolom++)
            printf("%c",'*');
        printf("\n");

    }
}
