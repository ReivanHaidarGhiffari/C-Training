#include <stdio.h>
main()
{
    int a,b,c;
    printf("masukkan tiga angka\n");
    scanf("%d %d %d", &a,&b,&c);
    if(a<b)
        if(a<c)
            printf("angka yang terkecil adalah %d",a);
        else
            printf("angka yang terkecil adalah %d",c);
    else if(b<c)
        printf("angka yang terkecil adalah %d",b);
    else
        printf("angka yang terkecil adalah %d",c);
}
