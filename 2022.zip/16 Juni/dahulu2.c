#include <stdio.h>
#include <stdlib.h>
main()
{
    char *tel= 'L';
    printf("T E %c E K O M U N I K A S I", tel);
}
