#include <stdio.h>

main()
{
    int a,b,c,d;
    printf("Masukan Bilangan pertama : ");
    scanf("%d",&a);
    printf("Masukan Bilangan Kedua : ");
    scanf("%d",&b);
    c=a=b;
    b=a;
    printf("Jadi bilangan pertama sekarang : %d \n",b);
    printf("Jadi bilangan kedua sekarang : %d ",c);

}
