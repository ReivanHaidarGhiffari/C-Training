#include <stdio.h>
main()
{
    int i,j,jumlah;
    float smtr;
    int x[10];

    printf("Tentukan Jumlah Bilangan\n ");
    scanf("%d", &jumlah);

    printf("Masukan bilangan yang akan diurut\n ");
    for(i=0;i<jumlah;i++)
        scanf("%d", &x[i]);


    for(i=0;i<jumlah-1;i++)
        for(j=i+1; j<jumlah;j++)
        if(x[i]>
        x[j])
    {
        smtr = x[i];
        x[i] = x[j];
        x[j] = smtr;
    }

    printf("setelah diurut = ");
    for(i=0;i<jumlah;i++)
        printf("%d" ,x[i]);
}
