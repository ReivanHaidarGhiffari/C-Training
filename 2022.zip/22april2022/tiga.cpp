
#include <stdio.h>
main()
{
    int n,bilangan,i;
    float total=0,rata;

    printf("banyaknya data:");
    scanf("%d",&n);

    for(i=1;i<=n;)
    {
        printf("data ke  %d",i);
        scanf("%d",&bilangan);
        if(bilangan<0)
            continue;
        total=total+bilangan;
        i++;
    }
    rata=total/n;
    printf("banyaknya mahasiswa %d\n",n);
    printf("total nilai mahasiswa %f\n",total);
    printf("rata-rata nilai mahasiswa %f\n",rata);
}
