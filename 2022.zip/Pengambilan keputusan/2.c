#include <stdio.h>

main()
{
    int a,b,c;
    printf("Masukan tiga angka\n");
    scanf("%d %d %d",&a,&b,&c);
    if(a<b)
        if(a<c)
         printf("Angka yang terkecil adalah %d",a);
    else
         printf("Angka yang terkecil adalah %d",c);
    else if(b<c)
         printf("Angka yang terkecil adalah %d",b);
    else
         printf("Angka yang terkecil adalah %d",c);

}
