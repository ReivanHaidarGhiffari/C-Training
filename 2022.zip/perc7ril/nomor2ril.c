#include <stdio.h>
float jumlah(int n);
main()
{
    int n;
    float total;
    printf("masukan jumlah data\n");
    scanf("%d", &n);

    total=jumlah(n);
    printf("Jadi totalnya adalah %f", total);
}
float jumlah (int n)
{
    int i,bil;
    float total=0;
    float rata;

    for(i=1;i<=n;i++)
    {
        printf("masukan bilangan ke %d",i);
        scanf("%d", &bil);
        total=total+bil;
    }
    rata=total/n;
    return rata;

}
