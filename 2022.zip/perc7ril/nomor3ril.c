#include <stdio.h>
void tukar();
int a,b,c;

main()
{
    printf("masukan 2 buah bilangan");
    scanf("%d %d", &a,&b);
    tukar();


}

void tukar()
{
    c=a;
    a=b;
    b=c;
    printf(" %d %d", a,b);

}
