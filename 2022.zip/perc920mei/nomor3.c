#include <stdio.h>
main()
{
    int rata;
    int a[3][3];
    int b[3][3];
    int i,j;
    int total;
    for(i=0;i<3;i++)
    {
        total=0;
        for(j=0;j<3;j++)
        {
            printf("nilai ke-%d ",j+1);
            scanf("%d",&a[i][j]);
            total=total+a[i][j];
        }
        rata=total/3;
        printf("rata ke %d adalah %d\n",i+1,rata);
    }
}
